---
name: Bug report
about: Create a report to help us improve
title: ''
labels: 'Type: Bug'
assignees: ''

---
**Description**

**Checklist**

- [ ] I've included a minimal example to reproduce the issue
- [ ] I'd be willing to make a PR to solve this issue